data = [
    {
        'f_name': 'Jonathan',
        'l_name': 'Moore',
        'is_staff': True
    },
    {
        'f_name': 'Rene',
        'l_name': 'Marino',
        'is_staff': True
    },
    {
        'f_name': 'Kyle',
        'l_name': 'Reimers',
        'is_staff': True
    },
    {
        'f_name': 'Peter',
        'l_name': 'Marino',
        'is_staff': True
    },
    {
        'f_name': 'Buzz',
        'l_name': 'Lightyear',
        'is_staff': False
    }
]